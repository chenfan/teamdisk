<?php
/*** 
TeamToy extenstion info block  
##name team_disk
##folder_name team_disk
##author chenfan
##reversion 1
##desp team_disk 云端存储。 
***/



// 添加顶部导航按钮
add_action( 'UI_USERMENU_BOTTOM' , 'team_disk_menu_list');
function team_disk_menu_list()
{
	?>
	<li><a href="javascript:show_float_box( 'Team Disk' , '?c=plugin&a=disk_setting' );void(0);">Team Disk</a></li>
	<?php 	 	
} 


// 添加顶部导航按钮
add_action( 'PLUGIN_DISK_SETTING' , 'plugin_disk_setting');
function plugin_disk_setting()
{
	$do = z(t(v('do')));

	switch( $do )
	{
		case 'create':
		case 'refresh':
			$dir = AROOT.'webdav/';
			$suc = true;
			if (file_exists($dir)) {

			} else {
			    $dir = mkdir($dir,0755,true);
			    if(!$dir)
			    	$suc = false;
			}
			$htaccess = AROOT.'webdav/.htaccess';

			if (file_exists($htaccess)) {

			} else {
			    $ht = file_put_contents($htaccess, '<IfModule mod_rewrite.c>
                RewriteEngine on
                RewriteCond %{REQUEST_URI} /webdav
                RewriteRule (.*) /?c=plugin&a=team_disk&file=%{REQUEST_URI} [L]
                </IfModule>');
			    if(!$ht)
			    	$suc = false;
			}
			kset('team_disk_open','on');
			if( $suc) return ajax_echo('done');
			else return ajax_echo('error');
			break;
		
		case 'close':
			kset('team_disk_open','off');
			return ajax_echo('done');
			break;
		case 'reopen':
			kset('team_disk_open','on');
			return ajax_echo('done');
			break;
		
		default:
			$data['tinfo'] = get_line( "SELECT * FROM `stoken` WHERE `uid` = '" . intval(uid()) . "' LIMIT 1" );
		render( $data , 'ajax' , 'plugin' , 'team_disk' ); 

	} 	
} 

// 添加显示页面的逻辑
add_action( 'PLUGIN_TEAM_DISK' , 'plugin_team_disk');
function  plugin_team_disk()
{

	$data['top'] = $data['top_title'] = '企业盘';
	$publicDir = '.';
	$tmpDir = 'tmpdata';
	$info  = kget('team_disk_open');
	if(!$info || $info=='off'){
		echo '已禁用或者没有初始化';
		die();
	}
	// If you want to run the SabreDAV server in a custom location (using mod_rewrite for instance)
	// You can override the baseUri here.
	$baseUri = '/';


	// Files we need
	require_once 'vendor/autoload.php';

	// Create the root node
	$root = new Sabre_DAV_FS_Directory($publicDir);

	// The rootnode needs in turn to be passed to the server class
	$server = new Sabre_DAV_Server();

	/* Database */
	//$pdo = new PDO('mysql:host=w.rdc.sae.sina.com.cn;port=3307;dbname=app_qyappwebdav','kappyyn1yn','yh20j4zz0h5j250kilww1ihwihh31hw4hk3hli3w');

	//$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


	if (isset($baseUri))
	    $server->setBaseUri($baseUri);

	// Support for LOCK and UNLOCK
	$lockBackend = new Sabre_DAV_Locks_Backend_File($tmpDir . '/locksdb');
	$lockPlugin = new Sabre_DAV_Locks_Plugin($lockBackend);
	$server->addPlugin($lockPlugin);

	// Support for html frontend
	$browser = new Sabre_DAV_Browser_Plugin();
	$server->addPlugin($browser);

	// Automatically guess (some) contenttypes, based on extesion
	$server->addPlugin(new Sabre_DAV_Browser_GuessContentType());

	// Authentication backend
	//$authBackend = new Sabre_DAV_Auth_Backend_File('.htdigest');
	//$authBackend      = new Sabre_DAV_Auth_Backend_PDO($pdo);
	//$auth = new Sabre_DAV_Auth_Plugin($authBackend,'SabreDAV');
	//$server->addPlugin($auth);
	$server->tree = new Sabre_DAV_ObjectTree($root); 
	// Temporary file filter
	$tempFF = new Sabre_DAV_TemporaryFileFilterPlugin($tmpDir);
	$server->addPlugin($tempFF);

	// And off we go! 
	$server->exec();
	
}